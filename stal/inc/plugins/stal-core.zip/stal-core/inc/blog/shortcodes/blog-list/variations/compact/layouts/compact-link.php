<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php
		// Include post format part
		stal_core_theme_template_part( 'blog', 'templates/parts/post-format/link' ); ?>
	</div>
</article>