<a id="qodef-mobile-header-opener" href="#">
	<span class="qodef-lines">
		<span class="qodef-line qodef-line-1"></span>
		<span class="qodef-line qodef-line-2"></span>
		<span class="qodef-line qodef-line-3"></span>
		<span class="qodef-line qodef-line-4"></span>
		<span class="qodef-line qodef-line-5"></span>
	</span>
</a>