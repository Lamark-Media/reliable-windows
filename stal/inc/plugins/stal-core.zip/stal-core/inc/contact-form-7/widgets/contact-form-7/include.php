<?php

include_once STAL_CORE_INC_PATH . '/contact-form-7/widgets/contact-form-7/contact-form-7.php';