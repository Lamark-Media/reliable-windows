<?php

include_once STAL_CORE_INC_PATH . '/header/helpers.php';
include_once STAL_CORE_INC_PATH . '/header/header.php';
include_once STAL_CORE_INC_PATH . '/header/headers.php';
include_once STAL_CORE_INC_PATH . '/header/template-functions.php';