<?php

include_once STAL_CORE_INC_PATH . '/header/scroll-appearance/fixed/helper.php';
include_once STAL_CORE_INC_PATH . '/header/scroll-appearance/fixed/dashboard/admin/fixed-header-options.php';